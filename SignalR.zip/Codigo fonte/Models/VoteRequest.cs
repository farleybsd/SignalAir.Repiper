﻿namespace RepiperSignalR.Models
{
    public class VoteRequest
    {
        public string UserId { get; set; }
        public int OptionId { get; set; }
    }
}
